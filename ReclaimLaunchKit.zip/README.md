# Reclaim Launch Kit

This folder contains everything needed to launch the Reclaim platform:
- Production-ready code component (roofing-inspection-app.tsx)
- Promo text and graphic spec files
- Launch guide for iPad deployments
