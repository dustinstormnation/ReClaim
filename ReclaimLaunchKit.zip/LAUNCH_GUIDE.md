# Launch Guide (iPad Friendly)

## 1. Compress Project
- In Files app, locate your Reclaim project folder.
- Long-press folder -> Compress -> creates `Reclaim.zip`.

## 2. Upload to GitHub
1. Safari -> github.com -> sign in.
2. "+" -> New repository:
   - Name: reclaimtool
   - Private or Public.
3. In repo -> Add file -> Upload files -> Select `Reclaim.zip` -> Commit.

## 3. Deploy on Vercel
1. Safari -> vercel.com/dashboard -> sign in.
2. New Project -> Import from Git -> select `reclaimtool`.
3. Add Environment Variables (copy/paste from Firebase):
   NEXT_PUBLIC_FIREBASE_API_KEY, AUTH_DOMAIN, PROJECT_ID, STORAGE_BUCKET, MESSAGING_SENDER_ID, APP_ID.
4. Deploy -> Wait ~60s.

## 4. Verify Live
- Open https://reclaimtool.com -> Login -> Test.
